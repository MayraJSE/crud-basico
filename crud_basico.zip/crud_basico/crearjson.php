<?php
    include("session.php");
    //$arch = $_GET['arch'];
    include("config.php");
    $query = "SELECT * FROM users";
    
    $result = mysqli_query($mysqli, $query);    
      
    $usuarios= mysql_JSON($result);   
    //Creamos el JSON   
    $json_string = json_encode($usuarios, JSON_UNESCAPED_UNICODE);
    //echo $json_string;

    
    $nombreArch="users.json";
    $archivo = fopen($nombreArch,"w+");
    fwrite($archivo,$json_string);
    fclose($archivo);
    
    echo '<script language="javascript">';
    echo 'alert("Archivo creado exitósamente");';
    echo 'window.location="users.php";';
    echo '</script>';
    
    function mysql_JSON($result)
    {
        $usuarios = array(); //creamos un array
        while($row = mysqli_fetch_array($result)) 
        { 	
            $nombre=$row['firstname'];
            $apellido1=$row['middlename'];            
            $apellido2= $row['lastname'] ;
            $fechaNac=$row['birthdate'];            
            $usuarios[] = array('nombre'=> $nombre, 'apellido1'=> $apellido1, 'apellido2'=> $apellido2,
                                'fechaNac'=> $fechaNac);

        }
        return $usuarios;	
    }    
?>

