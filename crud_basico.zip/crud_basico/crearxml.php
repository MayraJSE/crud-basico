<?php
    include("session.php");
    //$arch = $_GET['arch'];
    include("config.php");
    $query = "SELECT * FROM users";
    $result = mysqli_query($mysqli, $query);
    $archXML= mysql_XML($result);
     
    $nombreArch="users.xml";
    $archivo = fopen($nombreArch,"w+");
    fwrite($archivo,$archXML);
    fclose($archivo);
    
    echo '<script language="javascript">';
    echo 'alert("Archivo creado exitósamente");';
    echo 'window.location="users.php";';
    echo '</script>';

    function mysql_XML($resultado)
    {
        // creamos el documento XML			
        $contenido  = '<?xml version="1.0" encoding="utf8" ?>';	
        $contenido .= '<informacion>';	
        while ($row = mysqli_fetch_array($resultado)) {
            $contenido.="<usuario>";
            $contenido.="<name>".$row['firstname']."</name>";
            $contenido.="<primerApellido>".$row['middlename']."</primerApellido>";
            $contenido.="<segundoApellido>".$row['lastname'] ."</segundoApellido>";
            $contenido.="<fechaNacimiento>".$row['birthdate']."</fechaNacimiento>";
            $contenido.="</usuario>";		
        }
        $contenido.='</informacion>';				
        return $contenido;
    }    
?>